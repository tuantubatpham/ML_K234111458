def shape2a(n):
    if n <= 0:
        print("Invalid input!!!!!!!(N >0)")
        return
    if n % 2 == 0:
        print("Invalid input: N must be odd")
        return
    print(f"Pattern 2a with N={n}:")
    for i in range(n):
        for j in range(n):
            center = n // 2
            distance = max(abs(i - center), abs(j - center))
            print(distance, end=" ")
            j += 1
        print()
        i += 1


shape2a(9)
shape2a(10)
shape2a(11)