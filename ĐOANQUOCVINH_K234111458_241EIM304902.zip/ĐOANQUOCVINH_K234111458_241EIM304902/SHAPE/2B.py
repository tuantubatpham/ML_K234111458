def shape2b(n):
    mid = n // 2
    print(f"Shape with N={n}")
    for i in range(4):
        for j in range(n):
            if j == mid:
                print(" ", end=" ")
            else:
                print("*", end=" ")
        print()
    for i in range(5):
        for j in range(i):
            print(" ", end=" ")
        for j in range(mid - i):
            print("$", end=" ")
        print("@", end=" ")
        for j in range(mid - i):
            print("$", end=" ")
        print()
shape2b(9)
shape2b(10)
shape2b(11)